#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

#define MAX_BUFFER 1024

char queryUser();

void readDevice(char *);

void printHeader() {
  printf("\n//-------------------------------------");
  printf("\n//-------------------------------------");
  printf("\n//-------------------------------------\n");
}

void writeDevice();

void seekDevice();

int main () {

  char userInput = 'a';
  char userBuff[MAX_BUFFER];

  while (userInput != 'e') {
    userInput = queryUser();

    switch (userInput) {
      case 'r':
        readDevice(userBuff);
      break;

      case 'w':
        writeDevice();
      break;

      case 's':
        seekDevice();
      break;
    }
  }





}


char queryUser() {

  char input[20];

  char uInput = 'q';

  while (!((uInput == 'e') || (uInput == 'r') || (uInput == 'w') || (uInput == 's'))) {
    printf("Device actions:\n");
    printf("\tPress r to read from device.\n");
    printf("\tPress w to write to the device.\n");
    printf("\tPress s to seek into the device.\n");
    printf("\tPress e to exit from the device.\n");
    printf("Enter Command: ");
    fgets(input,20,stdin);
    uInput = input[0];
  }

  return uInput;
}



void readDevice(char * buff) {

  int fd = open("/dev/simple_char_device",O_RDWR);

  int ret = read(fd,buff,MAX_BUFFER);

  printf("Data read from the device: %s",buff);
}

void writeDevice() {

  char inputBuff[500];

  printHeader();

  printf("Enter data you want to write to the device: \n");
  fgets(inputBuff,500,stdin);

  int fd = open("/dev/simple_char_device", O_RDWR);
  write(fd, inputBuff, 500);
}

void seekDevice() {

  int cOffset;

  char offset[20];
  char uWhence[20];

  printHeader();



  printf("Enter an offset value: ");
  fgets(offset,20,stdin);
  printf("\nEnter a whence value: ");
  fgets(uWhence,20,stdin);

  int whence = uWhence[0];
  sscanf(offset,"%d",&cOffset);

  int fd = open("/dev/simple_char_device", O_RDWR);
  lseek(fd,cOffset,whence);

}
